# Iranian Plate > ILPv3
https://universe.roboflow.com/sultan-space/iranian-plate

Provided by a Roboflow user
License: CC BY 4.0

