# Persian-Car-Numbers > 2023-08-21 9:12pm
https://universe.roboflow.com/starvision/persian-car-numbers

Provided by a Roboflow user
License: CC BY 4.0

